public class FavoriteThings {
	public static void main(String[] args) {
		System.out.println("My Favorite Foods to Eat:");
		System.out.println("1. Pizza");
		System.out.println("2. Chicken Nuggets");
		System.out.print("3. Applesauce");
	}
}