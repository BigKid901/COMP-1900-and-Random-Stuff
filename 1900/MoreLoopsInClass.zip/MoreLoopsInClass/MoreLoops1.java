public class MoreLoops1 {
	public static void main(String [] args) {

	for (int i = 50; i < 123; i++) {
		System.out.println(i + " Sloths can swim faster than they can move on land");
	}
	System.out.println(" ");

	int i = 50;
	while (i < 123) {
		System.out.println(i + " Sloths can swim faster than they can move on land");
		i++;
	}
	}
}