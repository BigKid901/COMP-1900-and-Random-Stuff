public class MoreLoops2 {
	public static void main(String [] args) {


	int i = 13;
	while (i <= 35) {
		System.out.println(i + ". Sloths are very effiecient and sleep about 15 hours a day.");
		i++;
	}
		
	System.out.println();
	

	for (i = 13; i <= 35; i++) {
		System.out.println(i + ". Sloths are very effiecient and sleep about 15 hours a day.");
	}
	

	}
}