public class MoreLoops3 {
	public static void main(String [] args) {


	int i = 0;
	while (i < 50) {
		System.out.println((i + 1) + ". Sloths are cool");
		i++;
	}
		

	}
}